Database  state  state.txt __SQLDSN__
#ifdef SQLUSER
Database  state  USER         __SQLUSER__
#endif
#ifdef SQLPASS
Database  state  PASS         __SQLPASS__
#endif
Database  state  AUTO_NUMBER  00001
Database  state  COLUMN_DEF   "code=CHAR(8) NOT NULL PRIMARY KEY"
Database  state  COLUMN_DEF   "country=CHAR(20) DEFAULT '' NOT NULL, index(country)"
Database  state  COLUMN_DEF   "state=CHAR(20) DEFAULT '' NOT NULL, index(state)"
Database  state  COLUMN_DEF   "postcode=CHAR(20) DEFAULT '' NOT NULL, index(postcode)"
Database  state  COLUMN_DEF   "tax=text"
Database  state  COLUMN_DEF   "name=CHAR(64) DEFAULT '' NOT NULL, index(name)"
